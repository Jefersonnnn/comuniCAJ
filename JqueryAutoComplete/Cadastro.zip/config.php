<?php
define("SERVIDOR", "localhost");
define("USUARIO", "usuario");
define("SENHA", "senha");
define("BANCO", "banco");
?>
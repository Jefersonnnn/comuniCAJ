<?php
if($_SERVER["REQUEST_METHOD"] == "POST") {
$nome         = $_POST["nome"];
$email        = $_POST["email"];
$data         = "{$_POST["ano"]}-{$_POST["mes"]}-{$_POST["dia"]}";
$sexo         = $_POST["sexo"];
$preferencias = isset($_POST["preferencias"]) ? implode(",", $_POST["preferencias"]) : "";
$salario      = $_POST["salario"];
$endereco     = $_POST["endereco"];
$bairro       = $_POST["bairro"];
$cidade       = $_POST["cidade"];
$estados      = $_POST["estados"];
$login        = $_POST["login"];
$senha        = $_POST["senha"];

if(file_exists("init.php")) {
	require "init.php";		
} else {
	echo "Arquivo init.php nao foi encontrado";
	exit;
}

if(!function_exists("Abre_Conexao")) {
	echo "Erro o arquivo init.php foi auterado, nao existe a fun��o Abre_Conexao";
	exit;
}

Abre_Conexao();
if(@mysql_query("INSERT INTO usuarios VALUES (	NULL , '$nome', '$email', '$data' , '$sexo', 
'$preferencias', '$salario', '$endereco', '$bairro', '$cidade', '$estados', '$login', MD5( '$senha' ) )")) {

	if(mysql_affected_rows() == 1){
		echo "Registro efetuado com sucesso<br />";
	}	

} else {
	if(mysql_errno() == 1062) {
		echo $erros[mysql_errno()];
		exit;
	} else {	
		echo "Erro nao foi possivel efetuar o cadastro";
		exit;
	}	
	@mysql_close();
}

}
?>
<a href="index.html">Voltar</a>